import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

cred = credentials.Certificate(r'C:\Users\ogata shingo\A_2107\app\public\nokhik-firebase-adminsdk-furbv-c863b9be8e.json')
firebase_admin.initialize_app(cred)

db = firestore.client()
index = '英語'
list_id = []
articles = db.collection('article').stream()

for doc in articles:
    index_id = doc.id
    title = doc.to_dict()["title"]
    tag = doc.to_dict()["tag"]
    sentence = doc.to_dict()["sentence"]
    if index in tag:
        list_id.append(index_id) 
    elif index in title:
        list_id.append(index_id)
    elif index in sentence:
        list_id.append(index_id)

print(list_id)